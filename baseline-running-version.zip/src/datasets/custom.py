from torchvision import transforms
from torchvision.datasets import ImageFolder
from torch.utils.data import DataLoader
from .dataset import DatasetPair
import os


class CustomDataSet(DatasetPair):
    """
    Reads an Image Folder and loads it into pytorch DataLoader/Dataset.
    The file structure shall look like this:
    /path to gesten-datensatz repository/gesten-datensatz/gesture/source/train/start/0.jpg
    /path to gesten-datensatz repository/gesten-datensatz/gesture/source/train/start/1.jpg
    ...
    /path to gesten-datensatz repository/gesten-datensatz/gesture/source/train/stop/0.jpg
    ...
    /path to gesten-datensatz repository/gesten-datensatz/gesture/source/test/start/0.jpg
    ...
    /path to gesten-datensatz repository/gesten-datensatz/gesture/source/test/stop/0.jpg
    """
    def __init__(
        self,
        root_dir: str = "gesten_datensatz/gesture",
        dataset: str = "source",
        image_size: int = 32,
        batch_size: int = 32,
        num_workers: int = 0,
    ):
        # This may be varied
        transform_train = transforms.Compose(
            [
                transforms.Resize((image_size, image_size)),
                #transforms.RandomCrop(image_size, padding=4),
                #transforms.RandomHorizontalFlip(),
                transforms.ToTensor(),
            ]
        )

        transform_test = transforms.Compose(
            [transforms.Resize((image_size, image_size)), transforms.ToTensor()]
        )

        train_set = ImageFolder(
            os.path.join(root_dir, dataset, "train"), transform_train
        )
        test_set = ImageFolder(
            os.path.join(root_dir, dataset, "test"), transform_test
        )

        super().__init__(train_set=train_set, test_set=test_set, batch_size=batch_size, num_workers=num_workers)
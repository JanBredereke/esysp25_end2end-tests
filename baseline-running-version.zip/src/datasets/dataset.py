from torch.utils.data import Dataset
from torch.utils.data import DataLoader

class DatasetPair:
    def __init__(self, train_set: Dataset, test_set: Dataset, batch_size: int=32, num_workers: int=0):
        self.train_loader = DataLoader(
            train_set,
            batch_size=batch_size,
            shuffle=True,
            num_workers=num_workers,
        )

        self.test_loader = DataLoader(
            test_set,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers,
        )

        self.classes = train_set.class_to_idx
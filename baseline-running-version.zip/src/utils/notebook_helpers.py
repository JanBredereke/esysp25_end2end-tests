import sys
import netron
import torch
import matplotlib.pyplot as plt
import numpy as np
from IPython.display import IFrame

def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)


def img_show(img):
    """
    Show training/test images
    """
    img = img / 2 + 0.5 # Unnormalize
    npimg = img.numpy()
    plt.imshow(np.transpose(npimg, (1, 2, 0)))
    plt.show()


def select_device():
    """
    Selects appropriate device for training/inference
    Will automatically select cuda if an Nvidia GPU with appropriate drivers is available
    """
    return torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def show_in_netron(model_filename):
    """
    Show ONNX models in netron
    """
    netron.start(model_filename, address=('0.0.0.0', 8081), browse=False)
    return IFrame(src='http://127.0.0.1:8081/', width='100%', height=400)

from math import ceil, sqrt
from os.path import basename

import matplotlib.pyplot as plt
import torch
from torch.nn import Module
from torch.utils.data import DataLoader
from torchvision import transforms


class Validator():
    def __init__(self, model: Module, load_path: str, test_dataloader: DataLoader, print_test_information: bool = False,
                 device: torch.device = torch.device('cpu')) -> None:
        self.model = model
        self.load_path = load_path
        self.test_dataloader = test_dataloader
        self.device = device
        self.print_test_information = print_test_information
        self.total = 0

    def validate(self) -> None:
        dataiter = iter(self.test_dataloader)
        wrong = 0
        for batch in dataiter:
            batch_images, labels = batch

            self.images = batch_images

            self.model.load_state_dict(torch.load(self.load_path))
            outputs = self.model(batch_images)
            _, predicted = torch.max(outputs, 1)

            self.model = self.model.to(device=self.device)
            outputs = outputs.to(device=self.device)

            batch_size = len(batch)
            self.total = self.total + batch_size

            for i in range(batch_size):
                if predicted[i] != labels[i]:
                    if self.print_test_information:
                        predicted_label = int(str(predicted[i])[7:8])
                        # print the concrete name for wrongly predicted images (self.test_dataloader.dataset.imgs[i] returns tupel (path of the picture, class id)):
                        print("image %s/%s - wrong | predicted: %s" % (
                            self.test_dataloader.dataset.classes[self.test_dataloader.dataset.imgs[i][1]],
                            basename(self.test_dataloader.dataset.imgs[i][0]),
                            self.test_dataloader.dataset.classes[predicted_label]))
                        # print full path of image:
                        # print("picture path: %s" % (self.test_dataloader.dataset.imgs[i][0]))
                    wrong += 1

        print(
            f'\n {self.total} images. {wrong} were predicted wrong. Accuracy: {100 * (1 - wrong / self.total)}% \n')

        if self.print_test_information:
            self.__plot_test_pictures__()

    def __plot_test_pictures__(self):
        to_pil = transforms.ToPILImage()
        fig = plt.figure(figsize=(15, 15))
        len3 = int(self.total / 3)
        nrows = ncols = ceil(sqrt(self.total))

        for i in range(0, self.total):
            image = to_pil(self.images[i])
            sub = fig.add_subplot(nrows, ncols, i + 1)
            sub.set_title("%s/%s" % (self.test_dataloader.dataset.classes[self.test_dataloader.dataset.imgs[i][1]],
                                     basename(self.test_dataloader.dataset.imgs[i][0])))
            plt.axis('off')
            plt.imshow(image)

        plt.show()

import time
import torch
from torch.nn.modules.loss import CrossEntropyLoss
from torch.optim import Adam
from torch.nn import Module
from torch.utils.data import DataLoader

class Trainer():
    def __init__(self, model: Module, save_path: str, train_dataloader: DataLoader, device: torch.device = torch.device('cpu'), epochs: int = 10, print_every=10) -> None:
        self.model = model
        self.save_path = save_path
        self.train_dataloader = train_dataloader
        self.device = device
        self.epochs = epochs
        self.print_every = print_every
        

    def train(self):
        self.model = self.model.to(device=self.device)
        criterion = CrossEntropyLoss().to(device=self.device)
        optimizer = Adam(self.model.parameters())
        # print_every = 1
        print('Started Training:')
        start_time = time.time()
        for epoch in range(self.epochs):
            running_loss = 0.0
            for i, data in enumerate(self.train_dataloader):
                inputs, labels = data
                inputs = inputs.to(device=self.device)
                labels = labels.to(device=self.device)

                # zero the parameter gradients
                optimizer.zero_grad()

                # forward + backward + optimize
                outputs = self.model(inputs)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

                # print statistics
                running_loss += loss.item()
                if i % self.print_every == self.print_every - 1:
                    print('[Epoch %2d, Microbatches %5d] loss: %.3f' %
                        (epoch + 1, i + 1, running_loss / self.print_every))
                    running_loss = 0.0

        torch.save(self.model.state_dict(), self.save_path)
        print('Finished Training in %.3fs.' % (time.time() - start_time))
